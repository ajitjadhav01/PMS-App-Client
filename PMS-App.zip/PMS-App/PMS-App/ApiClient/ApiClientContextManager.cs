namespace PMS_App.ApiClient;

/// <summary>
/// Api client context manager to consume API 
/// </summary>	
public class ApiClientContextManager : IClientContextManager
{
    /// <summary>
    /// Static HttpClient as we don't want to create for every call.
    /// </summary>
    private static HttpClient _httpClient;

    private string _baseUri { get; set; }

    /// <summary>
    /// Default constructor
    /// </summary>
    /// <param name="baseUrl">Base Url for API</param>
    public ApiClientContextManager(string baseUrl)
    {
        _baseUri = baseUrl;
        _httpClient = HttpClientFactory.GetHttpClient();
    }

    /// <summary>
    /// CorrelationId/TrackingId header to be passed to API
    /// </summary>
    public string CorrelationId { get; set; }

    /// <summary>
    /// Make a GET request to API 
    /// </summary>
    /// <param name="relativeUrl"></param>
    /// <returns></returns>
    public async Task<HttpResponseMessage> GetAsync(string relativeUrl)
    {
        var httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, CombinePaths(_baseUri, relativeUrl));
        AddAdditionalHeaders(httpRequestMessage);
        return await _httpClient.SendAsync(httpRequestMessage);
    }

    /// <summary>
    /// Make a POST request to API
    /// </summary>
    /// <param name="relativeUrl"></param>
    /// <param name="requestBody"></param>
    /// <returns></returns>
    public async Task<HttpResponseMessage> PostAsync(string relativeUrl, JObject requestBody)
    {
        var httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, CombinePaths(_baseUri, relativeUrl));
        httpRequestMessage.Content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(requestBody), Encoding.UTF8, "application/json");
        AddAdditionalHeaders(httpRequestMessage);
        return await _httpClient.SendAsync(httpRequestMessage);
    }

    /// <summary>
    /// Make a PUT request to API
    /// </summary>
    /// <param name="relativeUrl"></param>
    /// <param name="requestBody"></param>
    /// <returns></returns>
    public async Task<HttpResponseMessage> PutAsync(string relativeUrl, JObject requestBody)
    {
        var httpRequestMessage = new HttpRequestMessage(HttpMethod.Put, CombinePaths(_baseUri, relativeUrl));
        httpRequestMessage.Content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(requestBody), Encoding.UTF8, "application/json");
        AddAdditionalHeaders(httpRequestMessage);
        return await _httpClient.SendAsync(httpRequestMessage);
    }

    /// <summary>
    /// Make a DELETE request ot API
    /// </summary>
    /// <param name="relativeUrl"></param>
    /// <returns></returns>
    public async Task<HttpResponseMessage> DeleteAsync(string relativeUrl)
    {
        var httpRequestMessage = new HttpRequestMessage(HttpMethod.Delete, CombinePaths(_baseUri, relativeUrl));
        AddAdditionalHeaders(httpRequestMessage);
        return await _httpClient.SendAsync(httpRequestMessage);
    }

    /// <summary>
    /// Add additional headers like culture, correlationid authtoken
    /// </summary>
    /// <returns></returns> 
    private void AddAdditionalHeaders(HttpRequestMessage request)
    {
        request.Headers.Add("Authorization", TokenHelper.GetApiToken());
        if (string.IsNullOrEmpty(CorrelationId))
        {
            CorrelationId = Guid.NewGuid().ToString();
        }
        request.Headers.Add("TrackingId", CorrelationId);
    }

    private static string CombinePaths(string str1, string str2)
    {
        str1 = str1.Trim();
        str2 = str2.Trim();
        return string.Format(
                                CultureInfo.InvariantCulture,
                                "{0}/{1}",
                                str1.EndsWith("/", StringComparison.OrdinalIgnoreCase) ? str1.Substring(0, str1.Length - 1) : str1,
            str2.StartsWith("/", StringComparison.OrdinalIgnoreCase) ? str2.Substring(1, str2.Length - 1) : str2);
    }
}

