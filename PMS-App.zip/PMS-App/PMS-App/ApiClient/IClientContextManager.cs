﻿namespace PMS_App.ApiClient;

/// <summary>
/// Interface to make it mockable.
/// </summary>
public interface IClientContextManager
{
    /// <summary>
    /// 
    /// </summary>
    string CorrelationId { get; set; }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="relativeUrl"></param>
    /// <returns></returns>
    Task<HttpResponseMessage> GetAsync(string relativeUrl);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="relativeUrl"></param>
    /// <param name="data"></param>
    /// <returns></returns>
    Task<HttpResponseMessage> PostAsync(string relativeUrl, JObject data);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="relativeUrl"></param>
    /// <param name="data"></param>
    /// <returns></returns>
    Task<HttpResponseMessage> PutAsync(string relativeUrl, JObject data);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="relativeUrl"></param>
    /// <param name="data"></param>
    /// <returns></returns>
    Task<HttpResponseMessage> DeleteAsync(string relativeUrl);
}