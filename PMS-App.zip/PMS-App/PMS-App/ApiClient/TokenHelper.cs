namespace PMS_App.ApiClient;

internal static class TokenHelper
{
    public static string GetApiToken()
    {
        return "Token";
    }

}
