namespace PMS_App.ApiClient;

internal class HttpClientFactory
{
    private static HttpClient _tokenClient;

    static object lockObject = new object();
    internal static HttpClient GetHttpClient()
    {
        if (_tokenClient == null)
        {
            lock (lockObject)
            {
                if (_tokenClient == null)
                {
                    _tokenClient = new HttpClient();
                }
            }
        }
        return _tokenClient;
    }
}
