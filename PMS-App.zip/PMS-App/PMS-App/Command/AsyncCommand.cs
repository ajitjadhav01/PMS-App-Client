﻿namespace PMS_App.Command;

public class AsyncCommand : IAsyncCommand
{
    //private readonly Action<object> _execute = null;
    //private readonly Func<object, bool> _canExecute = null;

    //public AsyncCommand(Action<object> execute) : this(execute, null)
    //{
    //}

    //public AsyncCommand(Action<object> execute, Func<object, bool> canExecute)
    //{
    //    _ = execute ?? throw new ArgumentNullException($"execute is null");
    //    _execute = execute;
    //    _canExecute = canExecute;
    //}

    private readonly Func<Task> _execute;
    private readonly Func<object, bool> _canExecute;

    public AsyncCommand(
    Func<Task> execute,
    Func<object, bool> canExecute = null)
    {
        _execute = execute;
        _canExecute = canExecute;
    }

    public event EventHandler CanExecuteChanged;

    public async Task ExecuteAsync()
    {
        await _execute();
    }

    #region Explicit implementations
    bool ICommand.CanExecute(object parameter)
    {
        return _canExecute == null ? true : _canExecute(parameter);
    }

    void ICommand.Execute(object parameter)
    {
        ExecuteAsync();
    }
    #endregion

    //public event EventHandler CanExecuteChanged;

    //public void OnCanExecuteChanged()
    //{
    //    CanExecuteChanged?.Invoke(this, new EventArgs());
    //}

    //public bool CanExecute(object parameter)
    //{
    //    return _canExecute == null ? true : _canExecute(parameter);
    //}

    //public void Execute(object parameter)
    //{
    //    _execute(parameter);
    //}
}
