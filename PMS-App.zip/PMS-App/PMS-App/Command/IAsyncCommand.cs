﻿
namespace PMS_App.Command;

public interface IAsyncCommand : ICommand
{
    Task ExecuteAsync();
}
