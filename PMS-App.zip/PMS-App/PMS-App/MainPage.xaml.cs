﻿using PMS_App.ViewModels;

namespace PMS_App;

public partial class MainPage : ContentPage
{
    //int count = 0;
    //MainPageViewModel mainPageViewModel = null;
    public MainPage(MainPageViewModel mainPageViewModel)
	{
		InitializeComponent();
		//mainPageViewModel = new MainPageViewModel();
		this.BindingContext = mainPageViewModel;
        mainPageViewModel.TestCompleted += MainPageViewModel_TestCompleted;
    }
    private void MainPageViewModel_TestCompleted(object sender, EventArgs e)
    {
        txtRender.Text = "Done";
    }


    //private void OnCounterClicked(object sender, EventArgs e)
    //{
    //	count++;

    //	if (count == 1)
    //		CounterBtn.Text = $"Clicked {count} time";
    //	else
    //		CounterBtn.Text = $"Clicked {count} times";

    //	SemanticScreenReader.Announce(CounterBtn.Text);
    //}
}

