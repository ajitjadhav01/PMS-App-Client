﻿using Microsoft.Maui.Platform;
using PMS_App.Controls;
using PMS_App.Handlers;

namespace PMS_App;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new LoginPage();
		//#if __ANDROID__
		//		Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping(nameof(CustomEntry), (handler, view) => {
		//			if(view is CustomEntry)
		//			{
		//				handler.view.PlatformView?.
		//			}

		//		});
		//		#endif


		//Borderless Entry
		Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping(nameof(BorderlessEntry), (handler, view) => {
		
			if(view is BorderlessEntry)
			{
#if __ANDROID__
	handler.PlatformView.SetBackgroundColor(Colors.Transparent.ToPlatform());
#elif __IOS__
	handler.PlatformView.BorderStyle= UIKit.UITextBorderStyle.None;
#elif WINDOWS
				handler.PlatformView.FontWeight = Microsoft.UI.Text.FontWeights.Thin;
#endif
			}
		
		});
	}
}
