﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS_App.Handlers
{
    public interface ICustomEntry : IView
    {
        public int CornerRadius { get;}
        public int BorderThickness { get; }
        public Thickness Padding { get; }
        public Color BorderColor { get; }
    }
}
