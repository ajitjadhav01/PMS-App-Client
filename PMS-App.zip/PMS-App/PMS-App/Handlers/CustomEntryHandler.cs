﻿//using Microsoft.Maui.Handlers;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace PMS_App.Handlers
//{
//    public partial class CustomEntryHandler
//    {
//        public static PropertyMapper<ICustomEntry, CustomEntryHandler> CustomEntryMapper = new PropertyMapper<ICustomEntry, CustomEntryHandler>(ViewHandler.ViewMapper)
//        {
//            [nameof(ICustomEntry.CornerRadius)] = MapCornerRadius,
//        };
//        public CustomEntryHandler() : base(CustomEntryMapper) { }

//        public CustomEntryHandler(PropertyMapper? mapper = null) : base(mapper ?? CustomEntryMapper) { }

//    }
//}
