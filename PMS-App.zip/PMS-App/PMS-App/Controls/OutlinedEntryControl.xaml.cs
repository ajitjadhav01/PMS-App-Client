namespace PMS_App.Controls;

public partial class OutlinedEntryControl : Grid
{
	public OutlinedEntryControl()
	{
		InitializeComponent();
	}

	public static readonly BindableProperty TextProperty = BindableProperty.Create(
		propertyName:nameof(Text),
		returnType: typeof(string),
		declaringType:typeof(OutlinedEntryControl),
		defaultValue:null,
		defaultBindingMode: BindingMode.TwoWay);

	public string Text
	{
		get => (string)GetValue( TextProperty ); 
		set => SetValue( TextProperty, value );
	}

    public static readonly BindableProperty PlaceholderProperty = BindableProperty.Create(
    propertyName: nameof(Placeholder),
    returnType: typeof(string),
    declaringType: typeof(OutlinedEntryControl),
    defaultValue: null,
    defaultBindingMode: BindingMode.OneWay);

    public string Placeholder
    {
        get => (string)GetValue(PlaceholderProperty);
        set => SetValue(PlaceholderProperty, value);
    }

    private void txtCustomEntry_Focused(object sender, FocusEventArgs e)
    {
        lblCustomEntryPlaceholder.FontSize = 11;
        lblCustomEntryPlaceholder.TranslateTo(0,-24,80,easing:Easing.Linear);
    }

    private void txtCustomEntry_Unfocused(object sender, FocusEventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(Text))
        {
            lblCustomEntryPlaceholder.FontSize = 11;
            lblCustomEntryPlaceholder.TranslateTo(0, -24, 80, easing: Easing.Linear);
        }
        else
        {
            lblCustomEntryPlaceholder.FontSize = 15;
            lblCustomEntryPlaceholder.TranslateTo(0, 0, 80, easing: Easing.Linear);
        }
    }

    private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
    {
        txtCustomEntry.Focus();
    }
}