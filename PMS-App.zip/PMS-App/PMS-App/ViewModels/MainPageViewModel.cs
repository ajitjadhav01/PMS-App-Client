﻿namespace PMS_App.ViewModels;

public class MainPageViewModel : ViewModelBase
{
    public event EventHandler TestCompleted;

    public IAsyncCommand Test { get; set; }
    public MainPageViewModel()
    {
        Test = new AsyncCommand(TestMethod);
    }

    private async Task TestMethod()
    {
        await Task.Run(() => { TestCompleted?.Invoke(this, new EventArgs()); });
        //return Task.FromResult<string>("Working As Expected.");
    }
}