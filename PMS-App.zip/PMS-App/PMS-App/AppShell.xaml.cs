﻿namespace PMS_App;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
